<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<link rel="icon" href="{{ asset('img/favicon.png')}}" type="image/x-icon"/>
	<title>HRMS</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
<link rel="icon" href="{{ asset('assets/img/icon.ico')}}" type="image/x-icon"/>
	<script src="{{ asset('assets/js/plugin/webfont/webfont.min.js')}}"></script>
		<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['{{ asset("assets/css/fonts.min.css")}}']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css')}}">
	<link rel="stylesheet" href="{{ asset('assets/css/atlantis.min.css')}}">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="{{ asset('assets/css/demo.css')}}">
</head>
<body>
	<div class="wrapper">

  @include('admin.include.header')
		<!-- Sidebar -->

		  @include('admin.include.sidebar')
		<!-- End Sidebar -->
		<div class="main-panel">
			<div class="page-header">
						<!-- <h4 class="page-title"> Request List</h4> -->

					</div>
			<div class="content">
				<div class="page-inner">

					<div class="row">
						<div class="col-md-12">
							<div class="card custom-card">
								<div class="card-header">

										<?php
$cos_success_rs = 0;
$per_spi_appli = 0;
$per_spi_hr = 0;
if ($start_date == '' && $end_date == '' && $employee_id == '') {
    $or_appli = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')

        ->get();
    $or_lince = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')
        ->where('registration.licence', '=', 'yes')

        ->get();
    $data['or_verify'] = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')

        ->where('registration.licence', '=', 'no')
        ->get();
    $or_verify = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')

        ->where('registration.licence', '=', 'no')
        ->get();
    $or_noverify = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'not approved')
        ->where('registration.licence', '=', 'no')

        ->get();

    $or_partner_ref = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('tareq_app.assign', '=', 'Partner')
        ->where('tareq_app.reffered', '!=', '')

        ->get();

    $bill_rs = DB::Table('billing')

        ->join('tareq_app', 'billing.emid', '=', 'tareq_app.emid')
        ->orderBy('billing.id', 'desc')
        ->select('billing.*', 'tareq_app.ref_id')
        ->get();
    $first_invoice_rs = DB::Table('tareq_app')

        ->join('billing', 'tareq_app.emid', '=', 'billing.emid')
        ->where('tareq_app.invoice', '=', 'Yes')
        ->orderBy('tareq_app.id', 'desc')
        ->select('tareq_app.*')
        ->get();
    $bill_paid_rs = DB::Table('payment')
        ->join('tareq_app', 'payment.emid', '=', 'tareq_app.emid')
        ->where(function ($query) {
            $query->where('payment.status', '=', 'paid')
                ->orWhere('payment.status', '=', 'partially paid');
        })
        ->orderBy('payment.id', 'desc')
        ->get();
    $sum = 0;
    foreach ($bill_rs as $val) {
        $sum = $sum + $val->amount;
    }

    $hr_rs = DB::Table('hr_apply')

        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_com_rs = DB::Table('hr_apply')

        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->orderBy('hr_apply.id', 'desc')
        ->where('hr_apply.status', '=', 'Complete')
        ->get();
    $hr_home_rs = DB::Table('hr_apply')

        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->orderBy('hr_apply.id', 'desc')
        ->where('hr_apply.home_off', '=', 'Yes')
        ->get();

    $hr_reject_rs = DB::Table('hr_apply')

        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->orderBy('hr_apply.id', 'desc')
        ->where('hr_apply.licence', '=', 'Rejected')
        ->get();
    $hr_granted_rs = DB::Table('hr_apply')

        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->orderBy('hr_apply.id', 'desc')
        ->where('hr_apply.licence', '=', 'Granted')
        ->get();
    $hr_wip_rs = DB::Table('hr_apply')

        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->orderBy('hr_apply.id', 'desc')
        ->where('hr_apply.status', '=', 'Incomplete')
        ->get();

    $need_action_apply_rs = DB::Table('tareq_app')

        ->where('need_action', '=', 'Yes')
        ->orderBy('id', 'desc')
        ->get();
    $need_action_hr_rs = DB::Table('hr_apply')

        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->orderBy('hr_apply.id', 'desc')
        ->where('hr_apply.need_action', '=', 'Yes')
        ->get();

    $cos_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();

    $cos_requesrt_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
    //->where('cos_apply_emp.status', '=', 'Request')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_pending_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->where('cos_apply_emp.status', '<>', 'Granted')
        ->where('cos_apply_emp.status', '<>', 'Rejected')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_granted_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')

        ->where('cos_apply_emp.status', '=', 'Granted')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_rejected_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')

        ->where('cos_apply_emp.status', '=', 'Rejected')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();

    $visafile_pending_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->whereNull('visa_file_emp.status')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();

    $visafile_granted_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->where('visa_file_emp.status', '=', 'Granted')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();
    $visafile_rejected_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->where('visa_file_emp.status', '=', 'Rejected')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();

    $recruitementfile_request_rs = DB::Table('recruitment_file_emp')
    //->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
    //->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
    //->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    $recruitementfile_pending_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
    //->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->whereNull('recruitment_file_emp.status')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    $recruitementfile_ongoing_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
        ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_emp.status', '=', 'Recruitment Ongoing')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();
    $recruitementfile_hired_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
        ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_emp.status', '=', 'Hired')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    if (count($cos_rs) != 0) {
        $cos_success_rs = (count($cos_granted_rs) * 100) / count($cos_rs);
    }

    $per_spi_appli = 0;
    $per_spi_hr = 0;

    $cos_further_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')

        ->where('cos_apply_emp.fur_query', '=', 'Yes')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $hr_lag_time_rs = DB::Table('hr_apply')

        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->orderBy('hr_apply.id', 'desc')
        ->where('hr_apply.status', '=', 'Incomplete')
        ->get();
}

if ($start_date == '' && $end_date == '' && $employee_id != '') {
    $or_appli = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->get();
    $or_lince = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')
        ->where('registration.licence', '=', 'yes')

        ->get();

    $or_partner_ref = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('tareq_app.assign', '=', 'Partner')
        ->where('tareq_app.reffered', '!=', '')

        ->get();

    $data['or_verify'] = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')

        ->where('registration.licence', '=', 'no')
        ->get();
    $or_verify = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('registration.licence', '=', 'no')
        ->get();
    $or_noverify = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'not approved')
        ->where('registration.licence', '=', 'no')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->get();
    $bill_rs = DB::Table('billing')
        ->join('role_authorization_admin_organ', 'billing.emid', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'billing.emid', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->orderBy('billing.id', 'desc')
        ->select('billing.*', 'tareq_app.ref_id')
        ->get();

    $first_invoice_rs = DB::Table('tareq_app')
        ->join('role_authorization_admin_organ', 'tareq_app.emid', '=', 'role_authorization_admin_organ.module_name')
        ->join('billing', 'tareq_app.emid', '=', 'billing.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('tareq_app.invoice', '=', 'Yes')
        ->orderBy('tareq_app.id', 'desc')
        ->select('tareq_app.*')
        ->get();
    $bill_paid_rs = DB::Table('payment')
        ->join('role_authorization_admin_organ', 'payment.emid', '=', 'role_authorization_admin_organ.module_name')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->join('tareq_app', 'payment.emid', '=', 'tareq_app.emid')
        ->where(function ($query) {
            $query->where('payment.status', '=', 'paid')
                ->orWhere('payment.status', '=', 'partially paid');
        })
        ->orderBy('payment.id', 'desc')
        ->get();
    $sum = 0;
    foreach ($bill_rs as $val) {
        $sum = $sum + $val->amount;
    }

    $hr_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->where('tareq_app.ref_id', '=', $employee_id)

        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_com_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.status', '=', 'Complete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_home_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.home_off', '=', 'Yes')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_reject_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.licence', '=', 'Rejected')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_granted_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.licence', '=', 'Granted')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_wip_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.status', '=', 'Incomplete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $need_action_apply_rs = DB::Table('tareq_app')
        ->where('ref_id', '=', $employee_id)
        ->where('need_action', '=', 'Yes')
        ->orderBy('id', 'desc')
        ->get();
    $need_action_hr_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.need_action', '=', 'Yes')
        ->orderBy('hr_apply.id', 'desc')
        ->get();

    $cos_further_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')->where('cos_apply_emp.fur_query', '=', 'Yes')
        ->where('cos_apply.employee_id', '=', $employee_id)
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->where('tareq_app.ref_id', '=', $employee_id)
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();

    $cos_requesrt_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->where('tareq_app.ref_id', '=', $employee_id)
    //->where('cos_apply_emp.status', '=', 'Request')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_pending_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('cos_apply_emp.status', '<>', 'Granted')
        ->where('cos_apply_emp.status', '<>', 'Rejected')

        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_granted_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->where('cos_apply.employee_id', '=', $employee_id)
        ->where('cos_apply_emp.status', '=', 'Granted')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_rejected_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->where('cos_apply.employee_id', '=', $employee_id)
        ->where('cos_apply_emp.status', '=', 'Rejected')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();

    $visafile_pending_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->where('visa_file_apply.employee_id', '=', $employee_id)
        ->whereNull('visa_file_emp.status')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();

    $visafile_granted_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->where('visa_file_apply.employee_id', '=', $employee_id)
        ->where('visa_file_emp.status', '=', 'Granted')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();
    $visafile_rejected_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->where('visa_file_apply.employee_id', '=', $employee_id)
        ->where('visa_file_emp.status', '=', 'Rejected')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();

    $recruitementfile_request_rs = DB::Table('recruitment_file_emp')
    //->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
    //->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
    //->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_apply.employee_id', '=', $employee_id)
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    $recruitementfile_pending_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
    //->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_apply.employee_id', '=', $employee_id)
        ->whereNull('recruitment_file_emp.status')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    $recruitementfile_ongoing_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
        ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_apply.employee_id', '=', $employee_id)
        ->where('recruitment_file_emp.status', '=', 'Recruitment Ongoing')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();
    $recruitementfile_hired_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
        ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_apply.employee_id', '=', $employee_id)
        ->where('recruitment_file_emp.status', '=', 'Hired')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    if (count($cos_rs) != 0) {
        $cos_success_rs = (count($cos_granted_rs) * 100) / count($cos_rs);
    }
    $fof = 0;
    if (count($or_lince) != 0) {
        $tokgg = DB::table('role_authorization_admin_time')->where('type', '=', 'Application Time')->first();
        foreach ($or_lince as $lival) {
            $tok = DB::table('rota_inst')->select(DB::raw('sum(w_hours) as w_hours'))->where('employee_id', '=', $employee_id)->where('type', '=', 'Application Time')->where('emid', '=', $lival->reg)->first();

            if (!empty($tok->w_hours)) {
                if ($tokgg->time >= ($tok->w_hours)) {

                } else {
                    $fof++;
                }
            } else {
                $fof++;
            }
        }

    }

    $gof = 0;
    if (count($hr_com_rs) != 0) {
        $tokgg = DB::table('role_authorization_admin_time')->where('type', '=', 'HR Time')->first();
        foreach ($hr_com_rs as $lival) {
            $tok = DB::table('rota_inst')->select(DB::raw('sum(w_hours) as w_hours'))->where('employee_id', '=', $employee_id)->where('type', '=', 'HR Time')->where('emid', '=', $lival->emid)->first();

            if (!empty($tok->w_hours)) {
                if ($tokgg->time >= ($tok->w_hours)) {

                } else {
                    $gof++;
                }
            } else {
                $gof++;
            }
        }
    }
    if (count($or_lince) != 0) {

        if ($fof >= 1) {
            $per_spi_appli = 1;
        } else {
            $per_spi_appli = 0;
        }} else {
        $per_spi_appli = 1;
    }

    if (count($hr_com_rs) != 0) {
        if ($gof >= 1) {
            $per_spi_hr = 1;
        } else {
            $per_spi_hr = 0;
        }
    } else {
        $per_spi_hr = 1;
    }

    $hr_lag_time_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.status', '=', 'Incomplete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();

}

if ($start_date != '' && $end_date != '' && $employee_id == '') {
    $start_date = date('Y-m-d', strtotime($start_date));
    $end_date = date('Y-m-d', strtotime($end_date));
    $or_appli = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->get();
    $or_lince = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')
        ->where('registration.licence', '=', 'yes')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])

        ->get();

    $or_partner_ref = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('tareq_app.assign', '=', 'Partner')
        ->where('tareq_app.reffered', '!=', '')

        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])

        ->get();

    $data['or_verify'] = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->where('registration.licence', '=', 'no')
        ->get();
    $or_verify = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')

        ->where('registration.licence', '=', 'no')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->get();
    $or_noverify = DB::Table('registration')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'not approved')
        ->where('registration.licence', '=', 'no')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])

        ->get();
    $bill_rs = DB::Table('billing')
        ->join('tareq_app', 'billing.emid', '=', 'tareq_app.emid')
        ->whereBetween('billing.date', [$start_date, $end_date])
        ->orderBy('billing.id', 'desc')
        ->select('billing.*', 'tareq_app.ref_id')
        ->get();
    $first_invoice_rs = DB::Table('tareq_app')
        ->join('billing', 'tareq_app.emid', '=', 'billing.emid')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->where('tareq_app.invoice', '=', 'Yes')
        ->orderBy('tareq_app.id', 'desc')
        ->select('tareq_app.*')
        ->get();
    $bill_paid_rs = DB::Table('payment')
        ->join('tareq_app', 'payment.emid', '=', 'tareq_app.emid')
        ->where(function ($query) {
            $query->where('payment.status', '=', 'paid')
                ->orWhere('payment.status', '=', 'partially paid');
        })
        ->whereBetween('payment.date', [$start_date, $end_date])
        ->orderBy('payment.id', 'desc')
        ->get();
    $sum = 0;
    foreach ($bill_rs as $val) {
        $sum = $sum + $val->amount;
    }

    $hr_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])

        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_com_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('hr_apply.status', '=', 'Complete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_home_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('hr_apply.home_off', '=', 'Yes')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_reject_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('hr_apply.licence', '=', 'Rejected')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_granted_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('hr_apply.licence', '=', 'Granted')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_wip_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('hr_apply.status', '=', 'Incomplete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $need_action_apply_rs = DB::Table('tareq_app')
        ->join('registration', 'tareq_app.emid', '=', 'registration.reg')
        ->where('registration.status', '=', 'active')

        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->where('tareq_app.need_action', '=', 'Yes')
        ->orderBy('tareq_app.id', 'desc')
        ->get();
    $need_action_hr_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('hr_apply.need_action', '=', 'Yes')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $cos_further_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->where('cos_apply_emp.fur_query', '=', 'Yes')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();

    $cos_requesrt_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
    //->where('cos_apply_emp.status', '=', 'Request')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_pending_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->where('cos_apply_emp.status', '<>', 'Granted')
        ->where('cos_apply_emp.status', '<>', 'Rejected')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_granted_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->where('cos_apply_emp.status', '=', 'Granted')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_rejected_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->where('cos_apply_emp.status', '=', 'Rejected')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $visafile_pending_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->whereBetween('visa_file_emp.update_new_ct', [$start_date, $end_date])
        ->whereNull('visa_file_emp.status')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();

    $visafile_granted_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->whereBetween('visa_file_emp.update_new_ct', [$start_date, $end_date])
        ->where('visa_file_emp.status', '=', 'Granted')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();
    $visafile_rejected_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->whereBetween('visa_file_emp.update_new_ct', [$start_date, $end_date])
        ->where('visa_file_emp.status', '=', 'Rejected')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();

    $recruitementfile_request_rs = DB::Table('recruitment_file_emp')
    //->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
    //->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
    //->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->whereBetween('recruitment_file_emp.update_new_ct', [$start_date, $end_date])
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    $recruitementfile_pending_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
    //->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->whereBetween('recruitment_file_emp.update_new_ct', [$start_date, $end_date])
        ->whereNull('recruitment_file_emp.status')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    $recruitementfile_ongoing_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
        ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->whereBetween('recruitment_file_emp.update_new_ct', [$start_date, $end_date])
        ->where('recruitment_file_emp.status', '=', 'Recruitment Ongoing')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();
    $recruitementfile_hired_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
        ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->whereBetween('recruitment_file_emp.update_new_ct', [$start_date, $end_date])
        ->where('recruitment_file_emp.status', '=', 'Hired')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    if (count($cos_rs) != 0) {
        $cos_success_rs = (count($cos_granted_rs) * 100) / count($cos_rs);
    }
    $per_spi_appli = 0;
    $per_spi_hr = 0;

    $hr_lag_time_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.sub_due_date', [$start_date, $end_date])
        ->where('hr_apply.status', '=', 'Incomplete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();

}

if ($start_date != '' && $end_date != '' && $employee_id != '') {

    $start_date = date('Y-m-d', strtotime($start_date));
    $end_date = date('Y-m-d', strtotime($end_date));

    $or_appli = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('registration.status', '=', 'active')

        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->get();
    $or_lince = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)

        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')
        ->where('registration.licence', '=', 'yes')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])

        ->where('tareq_app.ref_id', '=', $employee_id)
        ->get();
    $or_partner_ref = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('tareq_app.assign', '=', 'Partner')
        ->where('tareq_app.reffered', '!=', '')

        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])

        ->get();
    $data['or_verify'] = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')

        ->where('registration.licence', '=', 'no')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->get();
    $or_verify = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'approved')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('registration.licence', '=', 'no')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->get();
    $or_noverify = DB::Table('registration')
        ->join('role_authorization_admin_organ', 'registration.reg', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'registration.reg', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('registration.status', '=', 'active')
        ->where('registration.verify', '=', 'not approved')
        ->where('registration.licence', '=', 'no')
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->get();
    $bill_rs = DB::Table('billing')
        ->join('role_authorization_admin_organ', 'billing.emid', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'billing.emid', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->whereBetween('billing.date', [$start_date, $end_date])
        ->orderBy('billing.id', 'desc')
        ->select('billing.*', 'tareq_app.ref_id')
        ->get();
    $first_invoice_rs = DB::Table('tareq_app')
        ->join('role_authorization_admin_organ', 'tareq_app.emid', '=', 'role_authorization_admin_organ.module_name')
        ->join('billing', 'tareq_app.emid', '=', 'billing.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->where('tareq_app.invoice', '=', 'Yes')
        ->orderBy('tareq_app.id', 'desc')
        ->select('tareq_app.*')
        ->get();

    $bill_paid_rs = DB::Table('payment')
        ->join('role_authorization_admin_organ', 'payment.emid', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'payment.emid', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where(function ($query) {
            $query->where('payment.status', '=', 'paid')
                ->orWhere('payment.status', '=', 'partially paid');
        })
        ->whereBetween('payment.date', [$start_date, $end_date])
        ->orderBy('payment.id', 'desc')
        ->get();
    $sum = 0;
    foreach ($bill_rs as $val) {
        $sum = $sum + $val->amount;
    }

    $hr_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_com_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.status', '=', 'Complete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_home_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.home_off', '=', 'Yes')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_reject_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.licence', '=', 'Rejected')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_granted_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.licence', '=', 'Granted')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $hr_wip_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.status', '=', 'Incomplete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
    $need_action_apply_rs = DB::Table('tareq_app')
        ->join('registration', 'tareq_app.emid', '=', 'registration.reg')
        ->where('registration.status', '=', 'active')

        ->whereBetween('tareq_app.assign_date', [$start_date, $end_date])
        ->where('tareq_app.need_action', '=', 'Yes')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->orderBy('tareq_app.id', 'desc')
        ->get();
    $need_action_hr_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.update_new_ct', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.need_action', '=', 'Yes')
        ->orderBy('hr_apply.id', 'desc')
        ->get();

    $cos_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->where('tareq_app.ref_id', '=', $employee_id)
        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_further_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->where('cos_apply.employee_id', '=', $employee_id)
        ->where('cos_apply_emp.fur_query', '=', 'Yes')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_requesrt_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
    //->where('cos_apply_emp.status', '=', 'Request')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_pending_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->join('tareq_app', 'cos_apply.emid', '=', 'tareq_app.emid')

        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->where('cos_apply_emp.status', '<>', 'Granted')
        ->where('cos_apply_emp.status', '<>', 'Rejected')
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_granted_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->where('cos_apply.employee_id', '=', $employee_id)
        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->where('cos_apply_emp.status', '=', 'Granted')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();
    $cos_rejected_rs = DB::Table('cos_apply_emp')
        ->select('cos_apply_emp.*', 'cos_apply.id as cosid', 'cos_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('cos_apply', 'cos_apply.id', '=', 'cos_apply_emp.com_cos_apply_id', 'inner')
        ->join('employee', 'employee.id', '=', 'cos_apply_emp.com_employee_id', 'left')
        ->where('cos_apply.employee_id', '=', $employee_id)
        ->whereBetween('cos_apply_emp.update_new_ct', [$start_date, $end_date])
        ->where('cos_apply_emp.status', '=', 'Rejected')
        ->orderBy('cos_apply_emp.id', 'desc')
        ->get();

    $visafile_pending_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->where('visa_file_apply.employee_id', '=', $employee_id)
        ->whereBetween('visa_file_emp.update_new_ct', [$start_date, $end_date])
        ->whereNull('visa_file_emp.status')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();

    $visafile_granted_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->where('visa_file_apply.employee_id', '=', $employee_id)
        ->whereBetween('visa_file_emp.update_new_ct', [$start_date, $end_date])
        ->where('visa_file_emp.status', '=', 'Granted')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();
    $visafile_rejected_rs = DB::Table('visa_file_emp')
        ->select('visa_file_emp.*', 'visa_file_apply.id as visafileid', 'visa_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('visa_file_apply', 'visa_file_apply.id', '=', 'visa_file_emp.com_visa_apply_id', 'inner')
        ->join('tareq_app', 'visa_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'visa_file_emp.com_employee_id', 'left')
        ->where('visa_file_apply.employee_id', '=', $employee_id)
        ->whereBetween('visa_file_emp.update_new_ct', [$start_date, $end_date])
        ->where('visa_file_emp.status', '=', 'Rejected')
        ->orderBy('visa_file_apply.id', 'desc')
        ->get();

    $recruitementfile_request_rs = DB::Table('recruitment_file_emp')
    //->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
    // ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
    //->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_apply.employee_id', '=', $employee_id)
        ->whereBetween('recruitment_file_emp.update_new_ct', [$start_date, $end_date])
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    $recruitementfile_pending_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
    // ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_apply.employee_id', '=', $employee_id)
        ->whereBetween('recruitment_file_emp.update_new_ct', [$start_date, $end_date])
        ->whereNull('recruitment_file_emp.status')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    $recruitementfile_ongoing_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
        ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_apply.employee_id', '=', $employee_id)
        ->whereBetween('recruitment_file_emp.update_new_ct', [$start_date, $end_date])
        ->where('recruitment_file_emp.status', '=', 'Recruitment Ongoing')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();
    $recruitementfile_hired_rs = DB::Table('recruitment_file_emp')
        ->select('recruitment_file_emp.*', 'recruitment_file_apply.id as recruitmentfileid', 'recruitment_file_apply.employee_id', 'employee.emp_fname', 'employee.emp_mname', 'employee.emp_lname')
        ->join('recruitment_file_apply', 'recruitment_file_apply.id', '=', 'recruitment_file_emp.com_recruitment_apply_id', 'inner')
        ->join('tareq_app', 'recruitment_file_apply.emid', '=', 'tareq_app.emid')
        ->join('employee', 'employee.id', '=', 'recruitment_file_emp.com_employee_id', 'left')
        ->where('recruitment_file_apply.employee_id', '=', $employee_id)
        ->whereBetween('recruitment_file_emp.update_new_ct', [$start_date, $end_date])
        ->where('recruitment_file_emp.status', '=', 'Hired')
        ->orderBy('recruitment_file_emp.id', 'desc')
        ->get();

    if (count($cos_rs) != 0) {
        $cos_success_rs = (count($cos_granted_rs) * 100) / count($cos_rs);
    }

    $fof = 0;
    if (count($or_lince) != 0) {
        $tokgg = DB::table('role_authorization_admin_time')->where('type', '=', 'Application Time')->first();
        foreach ($or_lince as $lival) {
            $tok = DB::table('rota_inst')->select(DB::raw('sum(w_hours) as w_hours'))->where('employee_id', '=', $employee_id)->where('type', '=', 'Application Time')->where('emid', '=', $lival->reg)->first();

            if (!empty($tok->w_hours)) {
                if ($tokgg->time >= ($tok->w_hours)) {

                } else {
                    $fof++;
                }
            } else {
                $fof++;
            }
        }

    }

    $gof = 0;
    if (count($hr_com_rs) != 0) {
        $tokgg = DB::table('role_authorization_admin_time')->where('type', '=', 'HR Time')->first();
        foreach ($hr_com_rs as $lival) {
            $tok = DB::table('rota_inst')->select(DB::raw('sum(w_hours) as w_hours'))->where('employee_id', '=', $employee_id)->where('type', '=', 'HR Time')->where('emid', '=', $lival->emid)->first();

            if (!empty($tok->w_hours)) {
                if ($tokgg->time >= ($tok->w_hours)) {

                } else {
                    $gof++;
                }
            } else {
                $gof++;
            }
        }
    }

    if (count($or_lince) != 0) {
        if ($fof >= 1) {
            $per_spi_appli = 1;
        } else {
            $per_spi_appli = 0;
        }} else {
        $per_spi_appli = 1;
    }

    if (count($hr_com_rs) != 0) {
        if ($gof >= 1) {
            $per_spi_hr = 1;
        } else {
            $per_spi_hr = 0;
        }
    } else {
        $per_spi_hr = 1;
    }
    $hr_lag_time_rs = DB::Table('hr_apply')
        ->join('tareq_app', 'hr_apply.emid', '=', 'tareq_app.emid')
        ->whereBetween('hr_apply.sub_due_date', [$start_date, $end_date])
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('hr_apply.status', '=', 'Incomplete')
        ->orderBy('hr_apply.id', 'desc')
        ->get();
}

$ongo = 0;
foreach ($bill_rs as $valoh) {
    if ($valoh->hold_st == 'Yes') {
        $ongo++;
    }

}
$aydngo = 0;

if ($start_date == '' && $end_date == '' && $employee_id == '') {
    $bill30da_rs = DB::Table('billing')

        ->join('tareq_app', 'billing.emid', '=', 'tareq_app.emid')
        ->where('billing.status', '=', 'not paid')
        ->orderBy('billing.id', 'desc')

        ->select('billing.*', 'tareq_app.ref_id')
        ->get();

}

if ($start_date == '' && $end_date == '' && $employee_id != '') {
    $bill30da_rs = DB::Table('billing')
        ->join('role_authorization_admin_organ', 'billing.emid', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'billing.emid', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('billing.status', '=', 'not paid')
        ->orderBy('billing.id', 'desc')
        ->select('billing.*', 'tareq_app.ref_id')
        ->get();

}

if ($start_date != '' && $end_date != '' && $employee_id == '') {
    $start_date = date('Y-m-d', strtotime($start_date));
    $end_date = date('Y-m-d', strtotime($end_date));
    $bill30da_rs = DB::Table('billing')
        ->join('tareq_app', 'billing.emid', '=', 'tareq_app.emid')
        ->whereBetween('billing.date', [$start_date, $end_date])
        ->where('billing.status', '=', 'not paid')
        ->orderBy('billing.id', 'desc')
        ->select('billing.*', 'tareq_app.ref_id')
        ->get();
}

if ($start_date != '' && $end_date != '' && $employee_id != '') {

    $start_date = date('Y-m-d', strtotime($start_date));
    $end_date = date('Y-m-d', strtotime($end_date));

    $bill30da_rs = DB::Table('billing')
        ->join('role_authorization_admin_organ', 'billing.emid', '=', 'role_authorization_admin_organ.module_name')
        ->join('tareq_app', 'billing.emid', '=', 'tareq_app.emid')
        ->where('role_authorization_admin_organ.member_id', '=', $employee_id)
        ->where('tareq_app.ref_id', '=', $employee_id)
        ->where('billing.status', '=', 'not paid')
        ->whereBetween('billing.date', [$start_date, $end_date])
        ->orderBy('billing.id', 'desc')
        ->select('billing.*', 'tareq_app.ref_id')
        ->get();

}
$aydngo15 = 0;

foreach ($bill30da_rs as $companyjhnvg) {

    if ($companyjhnvg->status == 'not paid' && $companyjhnvg->hold_st != 'Yes' || $companyjhnvg->hold_st != ' ' || is_null($companyjhnvg->hold_st)) {

        $daten = date('Y-m-d', strtotime($companyjhnvg->date . '  + 30 days'));
        $daten15 = date('Y-m-d', strtotime($companyjhnvg->date . '  + 15 days'));

        if ($daten < date('Y-m-d')) {
            $aydngo++;
        }
        if ($daten15 < date('Y-m-d')) {
            $aydngo15++;
        }

    }

}

//dd($cos_requesrt_rs);

?>	<h4 class="card-title"><i class="fas fa-list"></i> Recruitment File Request List @if(count($recruitementfile_request_rs)!=0)

									<!-- <form  method="post" action="{{ url('superadmin/search-request-excel') }}" enctype="multipart/form-data" >
                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    	<input  value="<?php echo $employee_id; ?>"  name="employee_id" type="hidden" class="form-control input-border-bottom" required="" >
                                	<input  value="<?php echo $start_date; ?>"  name="start_date" type="hidden" class="form-control input-border-bottom" required="" >
										<input  value="<?php echo $end_date; ?>"  name="end_date" type="hidden" class="form-control input-border-bottom" required="" >

										 <button data-toggle="tooltip" data-placement="bottom" title="Download Excel " class="btn btn-default" style="margin-top: -30px;float:right;margin-right: 15px;background:none !important;" type="submit"><img  style="width: 35px;" src="{{ asset('img/excel-dnld.png')}}"></button>
											</form> -->

											@endif</h4>
									@if(Session::has('message'))
							<div class="alert alert-success" style="text-align:center;"><span class="glyphicon glyphicon-ok" ></span><em > {{ Session::get('message') }}</em></div>
					@endif
								</div>	<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
												<th>Sl.No.</th>
													<th>Organisation Name</th>
													<th>Organisation Employee Name</th>
                                                    <th>WPC Employee</th>
														<th>Candidate identified?</th>
															<th>Advert posted?</th>
																<th>Advert start date</th>
																	<th>Advert end date</th>

														<th>Date of interview</th>

													<th>Remarks</th>

												</tr>
											</thead>

											<tbody>
											  <?php $i = 1;?>
						@foreach($recruitementfile_request_rs as $company)
								<?php

$pass = DB::Table('registration')

    ->where('reg', '=', $company->emid)

    ->first();
$passname = DB::Table('users_admin_emp')

    ->where('employee_id', '=', $company->employee_id)

    ->first();

if (!empty($company->advert_start_date) && $company->advert_start_date != null) {

    $advert_start_date = date('d/m/Y', strtotime($company->advert_start_date));

} else {

    $advert_start_date = '';

}

if (!empty($company->advert_end_date) && $company->advert_end_date != null) {

    $advert_end_date = date('d/m/Y', strtotime($company->advert_end_date));

} else {

    $advert_end_date = '';

}
if (!empty($company->date_of_interview) && $company->date_of_interview != null) {

    $date_of_interview = date('d/m/Y', strtotime($company->date_of_interview));

} else {

    $date_of_interview = '';

}

?>
				<tr>

							<td>{{ $i }}</td>
							<td>{{ $pass->com_name }}</td>
							<td>{{ $company->employee_name }}</td>
                                                        <td>{{ $passname->name }}</td>
                                  <td>{{ $company->candidate_identified }}</td>
                               <td>{{ $company->advert_posted }}</td>
                                <td>{{$advert_start_date}}</td>
                                <td>{{$advert_end_date}}</td>

							<td>
{{$date_of_interview}}
                  </td>
							     <td>
                 {{$company->remarks}}
                  </td>

						</tr>
						<?php
$i++;?>



  @endforeach
            								</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>




					</div>
				</div>
			</div>
			 @include('admin.include.footer')
		</div>

	</div>
	<!--   Core JS Files   -->
	<script src="{{ asset('assets/js/core/jquery.3.2.1.min.js')}}"></script>
	<script src="{{ asset('assets/js/core/popper.min.js')}}"></script>
	<script src="{{ asset('assets/js/core/bootstrap.min.js')}}"></script>

	<!-- jQuery UI -->
	<script src="{{ asset('assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')}}"></script>
	<script src="{{ asset('assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js')}}"></script>

	<!-- jQuery Scrollbar -->
	<script src="{{ asset('assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')}}"></script>
	<!-- Datatables -->
	<script src="{{ asset('assets/js/plugin/datatables/datatables.min.js')}}"></script>
	<!-- Atlantis JS -->
	<script src="{{ asset('assets/js/atlantis.min.js')}}"></script>
	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="{{ asset('assets/js/setting-demo2.js')}}"></script>
	<script >
		$(document).ready(function() {
			$('#basic-datatables').DataTable({
			});

			$('#multi-filter-select').DataTable( {
				"pageLength": 5,
				initComplete: function () {
					this.api().columns().every( function () {
						var column = this;
						var select = $('<select class="form-control"><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
								);

							column
							.search( val ? '^'+val+'$' : '', true, false )
							.draw();
						} );

						column.data().unique().sort().each( function ( d, j ) {
							select.append( '<option value="'+d+'">'+d+'</option>' )
						} );
					} );
				}
			});

			// Add Row
			$('#add-row').DataTable({
				"pageLength": 5,
			});

			var action = '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

			$('#addRowButton').click(function() {
				$('#add-row').dataTable().fnAddData([
					$("#addName").val(),
					$("#addPosition").val(),
					$("#addOffice").val(),
					action
					]);
				$('#addRowModal').modal('hide');

			});
		});
	</script>
</body>
</html>