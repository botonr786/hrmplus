<footer class="footer">
				<div class="container-fluid">
					
				<div class="copyright ml-auto">
						&copy 2023 CLIMBR | All Right Reserved | Developed by <a href ="https://eitpl.in/" target="_blank">E.I.T</a>
					</div>			
				</div>
			</footer>