<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>HRMPLUS</title>
</head>

<body>
<div style="text-align:center;text-align: center;margin-top: 10%;">
<img src="{{ asset('assets/img/like.png')}}" alt="" />
<h2 style="text-align:center;">Organisation Information Successfully saved.</h2>
</div>
</body>
</html>
